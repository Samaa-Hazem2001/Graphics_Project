Based on your system, extract in this folder:
- "imgcmp-win-x64.zip" if you are on Windows.
- "imgcmp-linux-x64.zip" if you are on Linux.

If you are on Mac, there is no compiled version, so you need to compile "imgcmp" by yourself.
The source code can be found at: https://github.com/yahiaetman/imgcmp